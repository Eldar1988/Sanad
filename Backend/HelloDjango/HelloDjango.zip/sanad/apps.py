from django.apps import AppConfig


class SanadConfig(AppConfig):
    name = 'sanad'
